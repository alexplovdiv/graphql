var express = require('express');
var express_graphql = require('express-graphql');
var {buildSchema} = require('graphql');

var schema = buildSchema(`
    type Query {
        course(id: Int!): Course
        courses(topic: String): [Course]
    }
    type Mutation {
        updateCourseTopic(id: Int!, topic: String!): Course
    }
    type Course {
        id: Int
        title: String
        author: String
        description: String
        topic: String
        url: String
    }
`);

var coursesData = [
    {
        id: 1,
        title: 'Star Wars: Episode 1 - The Phantom Manace',
        author: 'George Lucas',
        description: 'Two Jedi escape a hostile blockade to find allies and come across a young boy who may bring balance to the Force, but the long dormant Sith resurface to claim their old glory.',
        genre: 'sci-fi',
        url: 'https://www.imdb.com/title/tt0120915/?ref_=nv_sr_srsg_0'
    },
    {
        id: 2,
        title: 'Star Wars: Episode 2 - Attack of the Clones',
        author: 'George Lucas',
        description: 'Ten years after initially meeting, Anakin Skywalker shares a forbidden romance with Padmé Amidala, while Obi-Wan Kenobi investigates an assassination attempt on the senator and discovers a secret clone army crafted for the Jedi.',
        genre: 'sci-fi',
        url: 'https://www.imdb.com/title/tt0121765/?ref_=nv_sr_srsg_10'
    },
    {
        id: 3,
        title: 'Star Wars: Episode 3 - Revenge of the Sith',
        author: 'George Lucas',
        description: 'Three years into the Clone Wars, the Jedi rescue Palpatine from Count Dooku. As Obi-Wan pursues a new threat, Anakin acts as a double agent between the Jedi Council and Palpatine and is lured into a sinister plan to rule the galaxy.',
        genre: 'sci-fi',
        url: 'https://www.imdb.com/title/tt0121766/?ref_=nv_sr_srsg_9'
    }
]

var getCourse = function(args) {
    var id = args.id;
    return coursesData.filter(course => {
        return course.id == id;
    })[0];
}

var getCourses = function(args) {
    if (args.topic) {
        var topic = args.topic;
        return coursesData.filter(course => course.topic === topic);
    } else {
        return coursesData;
    }
}

var updateCourseTopic = function({id, topic}) {
    coursesData.map(course => {
        if (course.id === id) {
            course.topic = topic;
            return course;
        }
    });
    return coursesData.filter(course => course.id === id)[0];
}


var root = {
    course: getCourse,
    courses: getCourses,
    updateCourseTopic: updateCourseTopic
};


var app = express();
app.use('/graphql', express_graphql({
    schema: schema,
    rootValue: root,
    graphiql: true
}));

app.listen(4000, () => console.log('Express GraphQL Server Now Running On localhost:4000/graphql'));